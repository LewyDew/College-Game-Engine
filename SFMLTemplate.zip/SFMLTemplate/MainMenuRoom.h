#pragma once

#include "SFMLRoom.h"

class MainMenuRoom : public SFMLRoom
{
public:
	MainMenuRoom();
};
