#pragma once

#include "SFMLRoom.h"

class Level01Room : public SFMLRoom
{
public:
	Level01Room();
};
