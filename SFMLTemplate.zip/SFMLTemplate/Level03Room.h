#pragma once
#pragma once

#include "SFMLRoom.h"

class Level03Room : public SFMLRoom
{
public:
	Level03Room();
};
