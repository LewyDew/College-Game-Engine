#pragma once

#include "SFMLRoom.h"

class Level02Room : public SFMLRoom
{
public:
	Level02Room();
};
#pragma once
